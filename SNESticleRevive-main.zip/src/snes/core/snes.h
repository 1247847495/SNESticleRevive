
#ifndef _SNES_H
#define _SNES_H

#include "emusys.h"

extern "C" {
#include "sndisasm.h"
#include "sncpu.h"
#include "snspcdisasm.h"
#include "snspc.h"
}
#include "snspcio.h"
#include "snspcdsp.h"
#include "snspcmix.h"
#include "snio.h"
#include "snppu.h"
#include "sndma.h"
#include "snrom.h"
#include "snppurender.h"
#include "sndebug.h"

#include "sndsp1.h"
#include "sndsp2.h"
#include "sndsp4.h"
#include "snobc1.h"
#include "sncx4.h"
#include "sngsu.h"
#include "snsdd1.h"
#include "snsrtc.h"

#define SNES_RAMSIZE  0x20000
#define SNES_SRAMSIZE (256 * 1024)

#define SNES_DSP1 1

class SnesSystem : public Emu::System
{
public:
    SnesSystem();
    ~SnesSystem();
    SNCpuT *GetCpu() {return &m_Cpu;}
    SNSpcT *GetSpc() {return &m_Spc;}
    SnesPPU *GetPPU() {return &m_PPU;}

    Uint32	GetFrame() {return m_uFrame;}
    Uint8	*GetSRAM() {return m_SRam;}

    void 	SetRom(class Emu::Rom *pRom);
    void	SetSnesRom(SnesRom *pRom);
    void	Reset();
    void	SoftReset();
	void	ExecuteFrame(Emu::SysInputT *pInput, class CRenderSurface *pTarget, class CMixBuffer *pSound, ModeE eMode);

    void	SaveState(struct SnesStateT *pState);
    Bool	RestoreState(struct SnesStateT *pState);

    void    SaveState(void *pState, Int32 nStateBytes);
    void    RestoreState(void *pState, Int32 nStateBytes);
    Int32   GetStateSize();

    Int32   GetSRAMBytes();
    Uint8   *GetSRAMData();

	virtual const char *GetString(StringE eString);
    virtual Uint32 GetSampleRate() {return 32000;}

    static const Char *GetRegName(Uint32 uAddr);


private:
	SNCpuT		m_Cpu;
	SnesPPU		m_PPU;
	SnesDMAC	m_DMAC;
	SnesIO		m_IO;
	SNSpcIO		m_SpcIO;
	SNSpcT		m_Spc;
	SNSpcDsp	m_SpcDsp;

	// extra hardware
	ISNDSP		*m_pDsp;

#if SNES_DSP1
	SNDSP1		m_DSP1;
	SNDSP2		m_DSP2;
	// DSP-4 (Top Gear 3000): HLE self-contained, sem firmware.
	SNDSP4		m_DSP4;
#endif

	SNOBC1		m_OBC1;

	SNCX4		m_CX4;

	// SuperFX / GSU (Star Fox, Yoshi's Island, etc.) -- core experimental
	SNGSU		m_GSU;

	SNSDD1		m_SDD1;
	Bool		m_bSDD1;

	SNSRTC		m_SRTC;
	Bool		m_bSRTC;
	Bool		m_bSuperFX;   // cartucho usa SuperFX/GSU -> rotear $3000-34FF

	SnesRom		*m_pRom;

	SnesPPURender	m_PPURender;
	SNSpcDspMixFull		m_SpcDspMixer;		    // non-deterministic mixer
	SNSpcDspMixSilent	m_SpcDspSilentMixer;    // deterministic mixer

	Uint32		m_uSramSize;

	/* Pilotwings rewrites the H/V timer while a scanline is already running.
	   These fields are transient scheduler state and are intentionally not
	   part of save states. */
	Bool		m_bDynamicHVIRQ;
	Bool		m_bLineIRQActive;
	Bool		m_bLineIRQReschedule;
	Bool		m_bLineIRQFired;
	Bool		m_bLineIRQInstant;
	Int32		m_nLineIRQCycle;
	Int32		m_nLineIRQClock;
	Uint8		m_Ram[SNES_RAMSIZE] _ALIGN(16);
	Uint8		m_SRam[SNES_SRAMSIZE] _ALIGN(16);


private:
	static Uint8 SNCPU_TRAPFUNC ReadMem(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteMem(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC Read2000(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  Write2000(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC Read4000(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  Write4000(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC ReadSRAM(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteSRAM(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC ReadDSP1(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteDSP1(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC ReadOBC1(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteOBC1(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC ReadCX4(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteCX4(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 SNCPU_TRAPFUNC ReadGSU(SNCpuT *pCpu, Uint32 uAddr);
	static void SNCPU_TRAPFUNC  WriteGSU(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
	static Uint8 CX4ReadMem(void *pCtx, Uint32 uAddr);

    static Uint8 SNCPU_TRAPFUNC Read2000Debug(SNCpuT *pCpu, Uint32 uAddr);
    static Uint8 SNCPU_TRAPFUNC Read4000Debug(SNCpuT *pCpu, Uint32 uAddr);
    static void SNCPU_TRAPFUNC  Write2000Debug(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);
    static void SNCPU_TRAPFUNC  Write4000Debug(SNCpuT *pCpu, Uint32 uAddr, Uint8 uData);



	void	MapLoRom();
	void	MapHiRom();
	void	MapMem(struct SnesMemMapT *pMemMap);
	void	MapMem(SNRomMappingE eRomMapping, Uint32 uFlags);
	void	MapMemExLoRom(void);
	void	RemapSDD1(void);   // (re)mapeia $C0-$FF conforme $4804-$4807
	void	DumpMemMap();

	void	SetFastRom();
	void	SetSlowRom();

	void	SyncSPC(Int32 uExtra = 0);
	void	SyncPPU();
	Int32	CalculateLineIRQCycle();
	void	RescheduleLineIRQ(Bool bAllowImmediate);
	void	ExecuteLine();
    void    ExecuteWithIRQ(Int32 nCycles, Int32 &nIRQCycles);
    void    ExecuteCPU(Int32 nExecCycles);
};

void SnesDebugBegin(SnesSystem *pSnes, const char *pFileName);
void SnesDebugEnd();

#endif
