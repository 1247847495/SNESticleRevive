

#ifndef _SNMASKOP_H
#define _SNMASKOP_H


#ifndef SNMASKOP_INLINE
#define SNMASKOP_INLINE (TRUE)
#endif

/* Keep the EE's two-qword MMI implementation in release builds, while host
   correctness/performance tests use the equivalent portable implementation. */
#ifndef SNMASKOP_ASSEMBLY
#define SNMASKOP_ASSEMBLY (CODE_PLATFORM == CODE_PS2)
#endif

void SNMaskRange(SNMaskT *pMask, Uint32 uLeft, Uint32 uRight, Bool bInvert);
void SNMaskRight(SNMaskT *pMask, Int32 iPos);
void SNMaskLeft(SNMaskT *pMask, Int32 iPos);

void SNMaskSHR(SNMaskT *pDestMask, const Uint8 *pSrcMask, Int32 nBits);
void SNMaskSHL(SNMaskT *pDestMask, const Uint8 *pSrcMask, Int32 nBits);

#if !SNMASKOP_INLINE

void SNMaskClear(SNMaskT *pDest);
void SNMaskSet(SNMaskT *pDest);
void SNMaskCopy(SNMaskT *pDest,  const SNMaskT *pSrc);

void SNMaskNOT(SNMaskT *pDest,  const SNMaskT *pSrc);
void SNMaskAND(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB);
void SNMaskANDN(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB);
void SNMaskOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB);
void SNMaskXOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB);
void SNMaskXNOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB);

void SNMaskBool(SNMaskT *pDest, const SNMaskT *pSrc, bool bVal);

#elif !SNMASKOP_ASSEMBLY

static inline void SNMaskClear(SNMaskT *pDest)
{
	pDest->uMask64[0] = 0;
	pDest->uMask64[1] = 0;
	pDest->uMask64[2] = 0;
	pDest->uMask64[3] = 0;
}

static inline void SNMaskSet(SNMaskT *pDest)
{
	pDest->uMask64[0] = ~(Uint64)0;
	pDest->uMask64[1] = ~(Uint64)0;
	pDest->uMask64[2] = ~(Uint64)0;
	pDest->uMask64[3] = ~(Uint64)0;
}


static inline void SNMaskCopy(SNMaskT *pDest,  const SNMaskT *pSrc)
{
	pDest->uMask64[0] = pSrc->uMask64[0];
	pDest->uMask64[1] = pSrc->uMask64[1];
	pDest->uMask64[2] = pSrc->uMask64[2];
	pDest->uMask64[3] = pSrc->uMask64[3];
}


static inline void SNMaskNOT(SNMaskT *pDest,  const SNMaskT *pSrc)
{
	// 0  1
	// 1  0
	// 0

	pDest->uMask64[0] = ~pSrc->uMask64[0];
	pDest->uMask64[1] = ~pSrc->uMask64[1];
	pDest->uMask64[2] = ~pSrc->uMask64[2];
	pDest->uMask64[3] = ~pSrc->uMask64[3];
}

static inline void SNMaskAND(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 0
	// 10 0
	// 11 1
	pDest->uMask64[0] = pSrcA->uMask64[0] & pSrcB->uMask64[0];
	pDest->uMask64[1] = pSrcA->uMask64[1] & pSrcB->uMask64[1];
	pDest->uMask64[2] = pSrcA->uMask64[2] & pSrcB->uMask64[2];
	pDest->uMask64[3] = pSrcA->uMask64[3] & pSrcB->uMask64[3];
}

static inline void SNMaskANDN(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 0
	// 10 1
	// 11 0

	pDest->uMask64[0] = pSrcA->uMask64[0] & ~pSrcB->uMask64[0];
	pDest->uMask64[1] = pSrcA->uMask64[1] & ~pSrcB->uMask64[1];
	pDest->uMask64[2] = pSrcA->uMask64[2] & ~pSrcB->uMask64[2];
	pDest->uMask64[3] = pSrcA->uMask64[3] & ~pSrcB->uMask64[3];
}


static inline void SNMaskOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 1
	// 10 1
	// 11 1
	pDest->uMask64[0] = pSrcA->uMask64[0] | pSrcB->uMask64[0];
	pDest->uMask64[1] = pSrcA->uMask64[1] | pSrcB->uMask64[1];
	pDest->uMask64[2] = pSrcA->uMask64[2] | pSrcB->uMask64[2];
	pDest->uMask64[3] = pSrcA->uMask64[3] | pSrcB->uMask64[3];
}

static inline void SNMaskXOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 1
	// 10 1
	// 11 0
	pDest->uMask64[0] = pSrcA->uMask64[0] ^ pSrcB->uMask64[0];
	pDest->uMask64[1] = pSrcA->uMask64[1] ^ pSrcB->uMask64[1];
	pDest->uMask64[2] = pSrcA->uMask64[2] ^ pSrcB->uMask64[2];
	pDest->uMask64[3] = pSrcA->uMask64[3] ^ pSrcB->uMask64[3];
}

static inline void SNMaskXNOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 1
	// 01 0
	// 10 0
	// 11 1
	pDest->uMask64[0] = ~(pSrcA->uMask64[0] ^ pSrcB->uMask64[0]);
	pDest->uMask64[1] = ~(pSrcA->uMask64[1] ^ pSrcB->uMask64[1]);
	pDest->uMask64[2] = ~(pSrcA->uMask64[2] ^ pSrcB->uMask64[2]);
	pDest->uMask64[3] = ~(pSrcA->uMask64[3] ^ pSrcB->uMask64[3]);
}

static inline void SNMaskBool(SNMaskT *pDest,  const SNMaskT *pSrc, bool bVal)
{
	// if bVal==true, then set bits of src in dest
	// if bVal==false, then clear bits of src in dest
	if (bVal)
	{
		SNMaskOR(pDest, pDest, pSrc);
	} else
	{
		SNMaskANDN(pDest, pDest, pSrc);
	}
}

#else

/* GCC 15 reorders memory accesses around plain `__asm__ __volatile__`
 * blocks unless told otherwise. Every one of the asm blocks below writes
 * to the 32-byte SNMaskT struct pointed to by pDest, but the input is
 * declared as a plain `"r" (pDest)` and there is no output operand to
 * tell GCC about the write. Without a `"memory"` clobber, GCC's TBAA
 * analysis can decide the mask struct hasn't changed and serve stale
 * cached values to subsequent C reads. GCC 3.2 happened to flush memory
 * around volatile asm by default; GCC 15 does not. The corruption shows
 * up as per-scanline BG/sprite mask bleed-through across SNMaskClear /
 * SNMaskCopy / SNMaskAND / etc., which is exactly the vertical-stripe
 * pattern visible on the SMW title screen in this codebase.
 *
 * Adding `"memory"` to every asm-block clobber list forces GCC to flush
 * and reload all memory the same way GCC 3.2 used to, restoring the
 * semantics the original SNESticle source assumed.
 */

static inline void SNMaskClear(SNMaskT *pDest)
{
    __asm__ __volatile__ (
    	"sq        $0,0x00(%0)     \n"
    	"sq        $0,0x10(%0)     \n"
    	: 
    	: "r" (pDest)
        : "memory"
     );    
}

static inline void SNMaskSet(SNMaskT *pDest)
{
    __asm__ __volatile__ (
        "pnor      $8,$0,$0        \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $8,0x10(%0)     \n"
    	: 
    	: "r" (pDest)
        : "$8", "memory"
     );    

}


static inline void SNMaskCopy(SNMaskT *pDest,  const SNMaskT *pSrc)
{
	// 0
    __asm__ __volatile__ (
        "lq        $8,0x00(%1)        \n"
        "lq        $9,0x10(%1)        \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrc)
        : "$8", "$9", "memory"
     );    
}


static inline void SNMaskNOT(SNMaskT *pDest,  const SNMaskT *pSrc)
{
	// 0  1
	// 1  0
	// 0
    __asm__ __volatile__ (
        "lq        $8,0x00(%1)        \n"
        "lq        $9,0x10(%1)        \n"
        "pnor      $8,$8,$0         \n"
        "pnor      $9,$9,$0         \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrc)
        : "$8", "$9", "memory"
     );    
}

static inline void SNMaskAND(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 0
	// 10 0
	// 11 1
    __asm__ __volatile__ (
        "lq         $8,0x00(%1)        \n"
        "lq         $9,0x10(%1)        \n"
        "lq        $10,0x00(%2)        \n"
        "lq        $11,0x10(%2)        \n"
        "pand      $8,$8,$10         \n"
        "pand      $9,$9,$11         \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrcA), "r" (pSrcB)
        : "$8", "$9", "$10", "$11", "memory"
     );    
}

static inline void SNMaskANDN(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 0
	// 10 1
	// 11 0
    __asm__ __volatile__ (
        "lq         $8,0x00(%1)        \n"
        "lq        $10,0x00(%2)        \n"
        "lq         $9,0x10(%1)        \n"
        "por       $8,$8,$10         \n"
        "lq        $11,0x10(%2)        \n"
        "pxor      $8,$8,$10         \n"
        "por       $9,$9,$11         \n"
    	"sq        $8,0x00(%0)     \n"
        "pxor      $9,$9,$11         \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrcA), "r" (pSrcB)
        : "$8", "$9", "$10", "$11", "memory"
     );    
}


static inline void SNMaskOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 1
	// 10 1
	// 11 1
    __asm__ __volatile__ (
        "lq         $8,0x00(%1)        \n"
        "lq         $9,0x10(%1)        \n"
        "lq        $10,0x00(%2)        \n"
        "lq        $11,0x10(%2)        \n"
        "por      $8,$8,$10         \n"
        "por       $9,$9,$11         \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrcA), "r" (pSrcB)
        : "$8", "$9", "$10", "$11", "memory"
     );    
}

static inline void SNMaskXOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 0
	// 01 1
	// 10 1
	// 11 0
    __asm__ __volatile__ (
        "lq         $8,0x00(%1)        \n"
        "lq         $9,0x10(%1)        \n"
        "lq        $10,0x00(%2)        \n"
        "lq        $11,0x10(%2)        \n"
        "pxor      $8,$8,$10         \n"
        "pxor       $9,$9,$11         \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrcA), "r" (pSrcB)
        : "$8", "$9", "$10", "$11", "memory"
     );    
}

static inline void SNMaskXNOR(SNMaskT *pDest,  const SNMaskT *pSrcA,  const SNMaskT *pSrcB)
{
	// 00 1
	// 01 0
	// 10 0
	// 11 1
    __asm__ __volatile__ (
        "lq         $8,0x00(%1)        \n"
        "lq         $9,0x10(%1)        \n"
        "lq        $10,0x00(%2)        \n"
        "lq        $11,0x10(%2)        \n"
        "pxor       $8,$8,$10         \n"
        "pxor       $9,$9,$11         \n"
        "pnor      $8,$8,$0         \n"
        "pnor      $9,$9,$0         \n"
    	"sq        $8,0x00(%0)     \n"
    	"sq        $9,0x10(%0)     \n"
    	: 
    	: "r" (pDest), "r" (pSrcA), "r" (pSrcB)
        : "$8", "$9", "$10", "$11", "memory"
     );    
}

static inline void SNMaskBool(SNMaskT *pDest,  const SNMaskT *pSrc, bool bVal)
{
	// if bVal==true, then set bits of src in dest
	// if bVal==false, then clear bits of src in dest
	if (bVal)
	{
		SNMaskOR(pDest, pDest, pSrc);
	} else
	{
		SNMaskANDN(pDest, pDest, pSrc);
	}
}

#endif

#endif
